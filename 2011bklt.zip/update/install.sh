#!/bin/sh
if [ ! -d ~/Bklt2_Backup ]; then
    mkdir ~/Bklt2_Backup
    cp -R /System/Library/Extensions/AppleGraphicsControl.kext ~/Bklt2_Backup
    cp -R /System/Library/Extensions/AppleBacklight.kext ~/Bklt2_Backup
fi
rm -R /System/Library/Extensions/AppleGraphicsControl.kext/Contents/PlugIns/AGDCBacklightControl.kext
rm -R /System/Library/Extensions/AppleGraphicsControl.kext/Contents/PlugIns/AppleMuxControl.kext
rm -R /System/Library/Extensions/AppleBacklight.kext
cp -R AppleMuxControl.kext /System/Library/Extensions/AppleGraphicsControl.kext/Contents/PlugIns
chmod -R 755 /System/Library/Extensions/AppleGraphicsControl.kext
chown -R 0:0 /System/Library/Extensions/AppleGraphicsControl.kext
