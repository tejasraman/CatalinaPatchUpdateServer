#!/bin/sh
chmod +x ./AMFITool
./AMFITool
rm -R /Library/Extensions/SIPManager.kext
