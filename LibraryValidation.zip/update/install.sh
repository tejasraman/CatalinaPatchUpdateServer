#!/bin/sh
cp DisableLibraryValidation.kext /System/Library/Extensions
chown -R 0:0 /System/Library/Extensions/DisableLibraryValidation.kext
chmod -R 755 /System/Library/Extensions/DisableLibraryValidation.kext
rm -R /Library/Extensions/SIPManager.kext
