#!/bin/sh

# Adding stock CoreBrightness.framework from 10.15.7
rm /System/Library/PrivateFrameworks/CoreBrightness.framework
cp CoreBrightness.framework /System/Library/PrivateFrameworks
chown -R 0:0 /System/Library/PrivateFrameworks/CoreBrightness.framework
chmod -R 755 /System/Library/PrivateFrameworks/CoreBrightness.framework

# Adding new KEXTs
cp -R Lilu.kext /System/Library/Extensions
cp -R WhateverGreen.kext /System/Library/Extensions
cp -R NightShiftEnabler.kext /System/Library/Extensions

# Permissions fix
chmod -R 755 /System/Library/Extensions/Lilu.kext
chown -R 0:0 /System/Library/Extensions/Lilu.kext
chown -R 0:0 /System/Library/Extensions/WhateverGreen.kext
chmod -R 755 /System/Library/Extensions/WhateverGreen.kext
chown -R 0:0 /System/Library/Extensions/NightShiftEnabler.kext
chmod -R 755 /System/Library/Extensions/NightShiftEnabler.kext