#!/bin/sh
cp -R AppleHDA.kext /System/Library/Extensions
cp -R IOAudioFamily.kext /System/Library/Extensions
chmod -R 755 /System/Library/Extensions/AppleHDA.kext
chown -R 0:0 /System/Library/Extensions/AppleHDA.kext
chmod -R 755 /System/Library/Extensions/IOAudioFamily.kext
chown -R 0:0 /System/Library/Extensions/IOAudioFamily.kext
